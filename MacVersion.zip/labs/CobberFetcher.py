# cobber_fetcher.py
# A PyQt6 application for fetching chemical data from PubChem and PDB.
# Drop-in replacement with:
#  - Fixed Qt stylesheets (no '#' misuse, proper :hover)
#  - Font fallback if 'Lato' is not installed
#  - PubChem fetching via robust PUG REST (with 3D→2D SDF fallback)
#  - Clean image handling and clearer error messages
#
# Requires:
#   pip install PyQt6 PyQt6-WebEngine requests pubchempy py3Dmol

import sys
import requests
from urllib.parse import quote_plus

from PyQt6.QtCore import Qt, QObject, pyqtSignal, QRunnable, QThreadPool
from PyQt6.QtGui import QPixmap, QImage, QFont, QFontDatabase, QColor
from PyQt6.QtWidgets import (
    QApplication, QMainWindow, QWidget, QSplitter, QVBoxLayout, QHBoxLayout,
    QFormLayout, QLabel, QTextEdit, QPushButton, QComboBox, QTabWidget,
    QMessageBox, QStatusBar, QDialog, QDialogButtonBox
)
from PyQt6.QtWebEngineWidgets import QWebEngineView

import pubchempy as pcp  # kept for compatibility, REST is used for reliability
import py3Dmol

# -----------------------
# HTTP session (robust)
# -----------------------
SESSION = requests.Session()
SESSION.headers.update({"User-Agent": "CobberLearnChem/1.0"})
DEFAULT_TIMEOUT = 15


# -----------------------
# Worker Signals
# -----------------------
class WorkerSignals(QObject):
    finished = pyqtSignal()
    result = pyqtSignal(dict)
    error = pyqtSignal(str)
    progress = pyqtSignal(str)


# -----------------------
# Background Worker
# -----------------------
class FetcherWorker(QRunnable):
    def __init__(self, db_choice, identifiers):
        super().__init__()
        self.db_choice = db_choice
        self.identifiers = identifiers
        self.signals = WorkerSignals()

    def run(self):
        try:
            for identifier in self.identifiers:
                identifier = identifier.strip()
                if not identifier:
                    continue

                self.signals.progress.emit(f"Fetching '{identifier}' from {self.db_choice}...")

                if self.db_choice == "PubChem":
                    data = self._fetch_pubchem_rest(identifier)
                else:
                    data = self._fetch_pdb(identifier)

                if data.get("error"):
                    self.signals.error.emit(data["error"])
                else:
                    self.signals.result.emit(data)
        except Exception as e:
            self.signals.error.emit(f"A critical error occurred: {e}")
        finally:
            self.signals.finished.emit()

    # ---------- PubChem via REST (robust) ----------
    def _fetch_pubchem_rest(self, identifier):
        try:
            # 1) Name -> CID  (URL-encode the name)
            name_q = quote_plus(identifier)
            r = SESSION.get(
                f"https://pubchem.ncbi.nlm.nih.gov/rest/pug/compound/name/{name_q}/cids/TXT",
                timeout=DEFAULT_TIMEOUT
            )
            r.raise_for_status()
            lines = [ln for ln in r.text.splitlines() if ln.strip()]
            if not lines:
                return {"error": f"Error: Could not find '{identifier}' in PubChem."}
            cid = lines[0]

            # 2) Properties via JSON (robust)
            props = SESSION.get(
                f"https://pubchem.ncbi.nlm.nih.gov/rest/pug/compound/cid/{cid}/property/"
                "MolecularFormula,MolecularWeight,CanonicalSMILES/JSON",
                timeout=DEFAULT_TIMEOUT
            )
            props.raise_for_status()
            pdata = props.json()
            rows = pdata.get("PropertyTable", {}).get("Properties", [])
            if not rows:
                return {"error": f"Error: No properties returned for CID {cid}."}
            row = rows[0]
            formula = row.get("MolecularFormula", "N/A")
            mw_val = row.get("MolecularWeight", None)
            if mw_val is not None:
                try:
                    weight = f"{float(mw_val):.2f} g/mol"
                except Exception:
                    weight = str(mw_val)
            else:
                weight = "N/A"
            smiles = row.get("CanonicalSMILES", "N/A")

            # 3) 2D PNG
            png = SESSION.get(
                f"https://pubchem.ncbi.nlm.nih.gov/rest/pug/compound/cid/{cid}/PNG?image_size=512x512",
                timeout=DEFAULT_TIMEOUT
            )
            png.raise_for_status()

            # 4) SDF (try 3D, then fall back to 2D)
            sdf = SESSION.get(
                f"https://pubchem.ncbi.nlm.nih.gov/rest/pug/compound/cid/{cid}/SDF?record_type=3d",
                timeout=DEFAULT_TIMEOUT
            )
            if not sdf.ok or "M  END" not in sdf.text:
                sdf = SESSION.get(
                    f"https://pubchem.ncbi.nlm.nih.gov/rest/pug/compound/cid/{cid}/SDF",
                    timeout=DEFAULT_TIMEOUT
                )
                sdf.raise_for_status()

            return {
                "type": "PubChem",
                "identifier": identifier,
                "cid": int(cid),
                "formula": formula,
                "weight": weight,
                "smiles": smiles,
                "image_data": png.content,
                "sdf_data": sdf.text,
            }

        except requests.HTTPError as e:
            # Helpful debug (optional): include the URL that failed
            try:
                failed_url = e.response.url
                return {"error": f"Error fetching data for '{identifier}': {e} ({failed_url})"}
            except Exception:
                return {"error": f"Error fetching data for '{identifier}': {e}"}
        except requests.RequestException as e:
            return {"error": f"Network error for '{identifier}': {e}"}
        except Exception:
            return {"error": f"Error: Could not find '{identifier}' in PubChem."}

    # ---------- PDB via RCSB ----------
    def _fetch_pdb(self, identifier):
        try:
            pdb_id = identifier.upper()

            # Metadata
            meta_url = f"https://data.rcsb.org/rest/v1/core/entry/{pdb_id}"
            meta_response = SESSION.get(meta_url, timeout=DEFAULT_TIMEOUT)
            meta_response.raise_for_status()
            meta_data = meta_response.json()

            # FASTA
            fasta_url = f"https://www.rcsb.org/fasta/entry/{pdb_id}/display"
            fasta_response = SESSION.get(fasta_url, timeout=DEFAULT_TIMEOUT)
            fasta_response.raise_for_status()
            fasta_lines = fasta_response.text.splitlines()

            # PDB file
            pdb_file_url = f"https://files.rcsb.org/download/{pdb_id}.pdb"
            pdb_file_response = SESSION.get(pdb_file_url, timeout=DEFAULT_TIMEOUT)
            pdb_file_response.raise_for_status()

            # Resolution (if present)
            resolution = "N/A"
            res_val = meta_data.get("rcsb_entry_info", {}).get("resolution_combined", [None])[0]
            if res_val is not None:
                try:
                    resolution = f"{float(res_val):.2f} \u00C5"
                except (ValueError, TypeError):
                    resolution = str(res_val)

            return {
                "type": "PDB",
                "identifier": pdb_id,
                "title": meta_data.get("struct", {}).get("title", "N/A"),
                "method": meta_data.get("exptl", [{}])[0].get("method", "N/A"),
                "resolution": resolution,
                "fasta": "\n".join(fasta_lines),
                "pdb_data": pdb_file_response.text,
            }
        except requests.RequestException:
            return {"error": f"Error: Could not find PDB ID '{identifier}' or failed to fetch data."}


# -----------------------
# 3D Molecule Viewer
# -----------------------
class MoleculeViewerDialog(QDialog):
    def __init__(self, title, sdf_content, parent=None):
        super().__init__(parent)
        self.setWindowTitle(title)
        self.setGeometry(200, 200, 540, 440)
        layout = QVBoxLayout(self)

        self.browser = QWebEngineView()

        view = py3Dmol.view(width=520, height=380)
        view.addModel(sdf_content, 'sdf')
        view.setStyle({'stick': {}})
        view.zoomTo()
        self.browser.setHtml(view._make_html())

        layout.addWidget(self.browser)

        button_box = QDialogButtonBox(QDialogButtonBox.StandardButton.Close)
        button_box.rejected.connect(self.reject)
        layout.addWidget(button_box)


# -----------------------
# Raw File Viewer
# -----------------------
class FileViewerDialog(QDialog):
    def __init__(self, title, content, parent=None):
        super().__init__(parent)
        self.setWindowTitle(title)
        self.setGeometry(200, 200, 640, 520)
        layout = QVBoxLayout(self)

        self.text_edit = QTextEdit(self)
        self.text_edit.setPlainText(content)
        self.text_edit.setReadOnly(True)
        self.text_edit.setFont(QFont("Courier", 10))

        layout.addWidget(self.text_edit)

        button_box = QDialogButtonBox(QDialogButtonBox.StandardButton.Close)
        button_box.rejected.connect(self.reject)
        layout.addWidget(button_box)


# -----------------------
# Main Window
# -----------------------
class CobberFetcherApp(QMainWindow):
    def __init__(self):
        super().__init__()

        # Branding colors
        self.cobber_maroon = QColor(108, 29, 69)
        self.cobber_gold = QColor(234, 170, 0)

        # Font fallback: use Lato if present, else Arial
        families = set(QFontDatabase.families())  # static in PyQt6
        self.base_font = QFont("Lato") if "Lato" in families else QFont("Arial")

        self.setFont(self.base_font)

        self.setWindowTitle("CobberFetcher")
        self.setGeometry(100, 100, 1200, 800)

        main_widget = QWidget()
        self.setCentralWidget(main_widget)
        main_layout = QHBoxLayout(main_widget)
        splitter = QSplitter(Qt.Orientation.Horizontal)
        main_layout.addWidget(splitter)

        self.threadpool = QThreadPool()

        # Left panel
        left_panel = QWidget()
        left_layout = QVBoxLayout(left_panel)
        left_panel.setMinimumWidth(300)
        left_panel.setMaximumWidth(420)

        form_layout = QFormLayout()
        self.db_combo = QComboBox()
        self.db_combo.addItems(["PubChem", "PDB"])
        form_layout.addRow(QLabel("Select Database:"), self.db_combo)

        input_label = QLabel("Enter Identifiers (one per line):")
        self.input_console = QTextEdit()
        self.input_console.setPlaceholderText("e.g., Aspirin\nIbuprofen\n\nor\n\n1MBO\n4E7V")

        button_layout = QHBoxLayout()
        self.fetch_btn = QPushButton("Fetch Data")
        self.fetch_btn.setStyleSheet(f"""
QPushButton {{
    background-color: {self.cobber_maroon.name()};
    color: white;
    font-size: 14px;
    font-weight: bold;
    padding: 8px;
    border-radius: 5px;
    font-family: 'Lato', 'Helvetica', 'Arial', sans-serif;
}}
QPushButton:hover {{
    background-color: #EAAA00;
}}
""")

        self.clear_btn = QPushButton("Clear All")
        self.clear_btn.setStyleSheet("""
QPushButton {
    padding: 8px;
    border-radius: 5px;
    font-family: 'Lato', 'Helvetica', 'Arial', sans-serif;
}
""")

        button_layout.addWidget(self.fetch_btn)
        button_layout.addWidget(self.clear_btn)

        report_label = QLabel("Report Log:")
        self.report_console = QTextEdit()
        self.report_console.setReadOnly(True)

        left_layout.addLayout(form_layout)
        left_layout.addWidget(input_label)
        left_layout.addWidget(self.input_console, 1)
        left_layout.addLayout(button_layout)
        left_layout.addWidget(report_label)
        left_layout.addWidget(self.report_console, 1)

        # Right panel (tabs)
        right_panel = QWidget()
        right_layout = QVBoxLayout(right_panel)
        self.tabs = QTabWidget()
        right_layout.addWidget(self.tabs)

        splitter.addWidget(left_panel)
        splitter.addWidget(right_panel)
        splitter.setStretchFactor(1, 1)

        self.setStatusBar(QStatusBar())
        self.statusBar().showMessage("Ready. Select a database and enter identifiers.")

        # Wire up
        self.fetch_btn.clicked.connect(self.start_fetching)
        self.clear_btn.clicked.connect(self.clear_all)

    # ---- slots/actions ----
    def start_fetching(self):
        raw_text = self.input_console.toPlainText()
        identifiers = [line for line in raw_text.splitlines() if line.strip()]
        if not identifiers:
            QMessageBox.warning(self, "Input Error", "Please enter at least one identifier.")
            return

        self.fetch_btn.setEnabled(False)
        self.clear_btn.setEnabled(False)
        self.report_console.clear()

        worker = FetcherWorker(self.db_combo.currentText(), identifiers)
        worker.signals.result.connect(self.add_result_tab)
        worker.signals.error.connect(self.log_error)
        worker.signals.progress.connect(self.statusBar().showMessage)
        worker.signals.finished.connect(self.on_fetching_finished)
        self.threadpool.start(worker)

    def on_fetching_finished(self):
        self.statusBar().showMessage("Fetching complete.", 5000)
        self.fetch_btn.setEnabled(True)
        self.clear_btn.setEnabled(True)

    def log_error(self, error_message):
        self.report_console.append(f"<font color='red'>{error_message}</font>")

    def add_result_tab(self, data):
        if data["type"] == "PubChem":
            self.create_pubchem_tab(data)
        else:
            self.create_pdb_tab(data)
        self.report_console.append(f"<font color='green'>Success: Fetched '{data['identifier']}'.</font>")

    def create_pubchem_tab(self, data):
        tab = QWidget()
        layout = QVBoxLayout(tab)

        title_label = QLabel(f"<b>{data['identifier']} (CID: {data['cid']})</b>")
        title_label.setFont(QFont(self.font().family(), 14, QFont.Weight.Bold))

        # Image
        q_img = QImage.fromData(data["image_data"])
        pixmap = QPixmap.fromImage(q_img)
        image_label = QLabel()
        image_label.setPixmap(
            pixmap.scaled(256, 256, Qt.AspectRatioMode.KeepAspectRatio, Qt.TransformationMode.SmoothTransformation)
        )
        image_label.setAlignment(Qt.AlignmentFlag.AlignCenter)

        # Info
        info_layout = QFormLayout()
        info_layout.addRow(QLabel("<b>Formula:</b>"), QLabel(data.get('formula', 'N/A')))
        info_layout.addRow(QLabel("<b>Mol. Weight:</b>"), QLabel(data.get('weight', 'N/A')))

        smiles_label = QTextEdit(data.get('smiles', 'N/A'))
        smiles_label.setReadOnly(True)
        smiles_label.setMaximumHeight(50)
        info_layout.addRow(QLabel("<b>SMILES:</b>"), smiles_label)

        # 3D button
        view_3d_button = QPushButton("View 3D Structure")
        view_3d_button.clicked.connect(
            lambda: self.show_molecule_viewer(f"3D Viewer: {data['identifier']}", data['sdf_data'])
        )

        layout.addWidget(title_label)
        layout.addWidget(image_label)
        layout.addLayout(info_layout)
        layout.addWidget(view_3d_button)
        layout.addStretch()
        self.tabs.addTab(tab, data['identifier'])

    def create_pdb_tab(self, data):
        tab = QWidget()
        layout = QVBoxLayout(tab)

        title_label = QLabel(f"<b>{data['identifier']}</b>")
        title_label.setFont(QFont(self.font().family(), 14, QFont.Weight.Bold))

        info_layout = QFormLayout()
        info_layout.addRow(QLabel("<b>Title:</b>"), QLabel(data.get('title', 'N/A')))
        info_layout.addRow(QLabel("<b>Method:</b>"), QLabel(data.get('method', 'N/A')))
        info_layout.addRow(QLabel("<b>Resolution:</b>"), QLabel(data.get('resolution', 'N/A')))

        fasta_label = QLabel("<b>FASTA Sequence:</b>")
        fasta_text = QTextEdit(data.get('fasta', ''))
        fasta_text.setReadOnly(True)
        fasta_text.setFont(QFont("Courier", 10))

        pdb_button = QPushButton("View PDB File")
        pdb_button.clicked.connect(
            lambda: self.show_file_viewer(f"PDB: {data['identifier']}", data['pdb_data'])
        )

        layout.addWidget(title_label)
        layout.addLayout(info_layout)
        layout.addWidget(fasta_label)
        layout.addWidget(fasta_text)
        layout.addWidget(pdb_button)
        layout.addStretch()
        self.tabs.addTab(tab, data['identifier'])

    def show_molecule_viewer(self, title, sdf_content):
        dialog = MoleculeViewerDialog(title, sdf_content, self)
        dialog.exec()

    def show_file_viewer(self, title, content):
        dialog = FileViewerDialog(title, content, self)
        dialog.exec()

    def clear_all(self):
        self.input_console.clear()
        self.report_console.clear()
        self.tabs.clear()
        self.statusBar().showMessage("Ready. Select a database and enter identifiers.")


# -----------------------
# Standalone entry
# -----------------------
if __name__ == '__main__':
    # Note (python.org builds): if HTTPS fails on macOS, run once:
    # /Applications/Python\ 3.12/Install\ Certificates.command
    app = QApplication(sys.argv)
    window = CobberFetcherApp()
    window.show()
    sys.exit(app.exec())
